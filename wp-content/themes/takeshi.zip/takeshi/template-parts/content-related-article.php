<?php
/**
 *
 * Template part for showing related posts.
 *
 */

?>

