<?php
/*
Template Name: Site map
*/
?>

<?php get_header(); ?>
Hello world
<?php get_footer(); ?>
