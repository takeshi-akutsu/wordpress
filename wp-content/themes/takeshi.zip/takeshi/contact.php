<?php
/*
Template Name: Contact page
*/
?>

<?php get_header(); ?>
[freehtml5map id="0"]
<?php get_footer(); ?>
